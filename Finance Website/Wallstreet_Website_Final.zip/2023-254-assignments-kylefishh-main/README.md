this is my first website as my socio informatics 254 assignment
